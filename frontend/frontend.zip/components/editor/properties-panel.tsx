"use client"

import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { NumericInput } from "@/components/ui/numeric-input"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Trash2,
  Palette,
  Move,
  RotateCw,
  Layers,
  Crop,
  Minus,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Copy,
  Clipboard,
  FlipHorizontal,
  FlipVertical,
  ArrowUp,
  ArrowDown,
  Square,
  Circle,
  Triangle,
  Type,
  Image as ImageIcon,
  Sparkles,
  Filter,
  Blend,
  Contrast,
  Sun,
  Droplet,
  Zap,
  RefreshCw,
  ChevronDown,
  Grid3x3,
  AlignHorizontalJustifyCenter,
  AlignVerticalJustifyCenter,
} from "lucide-react"
import { useState, useCallback, useMemo, useRef, useEffect } from "react"
import { ImageCropper } from "@/components/ui/image-cropper"

// Debounce utility for slider updates
function useDebounce(callback: (...args: any[]) => void, delay: number) {
  const timeoutRef = useRef<NodeJS.Timeout>()

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [])

  return useCallback(
    (...args: any[]) => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
      timeoutRef.current = setTimeout(() => {
        callback(...args)
      }, delay)
    },
    [callback, delay],
  )
}

interface PropertiesPanelProps {
  activeObject: any
  onUpdate: (property: string, value: any) => void
  onDelete: () => void
  onDuplicate?: () => void
  onReplaceImage?: (newImageUrl: string) => void
  onBringToFront?: () => void
  onSendToBack?: () => void
  onBringForward?: () => void
  onSendBackward?: () => void
}

// Color presets organized by category
const colorCategories = {
  "Basic Colors": [
    { color: "#000000", name: "Black" },
    { color: "#FFFFFF", name: "White" },
    { color: "#808080", name: "Gray" },
    { color: "#C0C0C0", name: "Silver" },
  ],
  "Primary Colors": [
    { color: "#EF4444", name: "Red" },
    { color: "#F59E0B", name: "Orange" },
    { color: "#EAB308", name: "Yellow" },
    { color: "#10B981", name: "Green" },
    { color: "#3B82F6", name: "Blue" },
    { color: "#8B5CF6", name: "Purple" },
    { color: "#EC4899", name: "Pink" },
  ],
  "Pastels": [
    { color: "#FCA5A5", name: "Light Red" },
    { color: "#FCD34D", name: "Light Yellow" },
    { color: "#86EFAC", name: "Light Green" },
    { color: "#93C5FD", name: "Light Blue" },
    { color: "#C4B5FD", name: "Light Purple" },
    { color: "#F9A8D4", name: "Light Pink" },
  ],
  "Dark Tones": [
    { color: "#7F1D1D", name: "Dark Red" },
    { color: "#78350F", name: "Dark Orange" },
    { color: "#065F46", name: "Dark Green" },
    { color: "#1E3A8A", name: "Dark Blue" },
    { color: "#581C87", name: "Dark Purple" },
  ],
}

// Gradient presets
const gradientPresets = [
  { name: "Sunset", colors: ["#FF6B6B", "#FFD93D", "#6BCF7F"], angle: 45 },
  { name: "Ocean", colors: ["#0284c7", "#06b6d4", "#22d3ee"], angle: 135 },
  { name: "Purple Dream", colors: ["#7c3aed", "#a78bfa", "#c4b5fd"], angle: 90 },
  { name: "Fire", colors: ["#ff0844", "#ffb199", "#ffd93d"], angle: 180 },
  { name: "Forest", colors: ["#065f46", "#059669", "#10b981"], angle: 0 },
  { name: "Night Sky", colors: ["#0f172a", "#1e293b", "#334155"], angle: 45 },
  { name: "Cherry Blossom", colors: ["#fda4af", "#f9a8d4", "#f0abfc"], angle: 90 },
  { name: "Gold Rush", colors: ["#d97706", "#f59e0b", "#fbbf24"], angle: 135 },
]

// Blend modes
const blendModes = [
  "normal",
  "multiply",
  "screen",
  "overlay",
  "darken",
  "lighten",
  "color-dodge",
  "color-burn",
  "hard-light",
  "soft-light",
  "difference",
  "exclusion",
]

// Font families
const fontFamilies = [
  "Arial",
  "Helvetica",
  "Times New Roman",
  "Georgia",
  "Verdana",
  "Courier New",
  "Comic Sans MS",
  "Impact",
  "Trebuchet MS",
  "Palatino",
  "Garamond",
  "Bookman",
  "Avant Garde",
]

// Font weights
const fontWeights = [
  { value: "100", label: "Thin" },
  { value: "200", label: "Extra Light" },
  { value: "300", label: "Light" },
  { value: "400", label: "Regular" },
  { value: "500", label: "Medium" },
  { value: "600", label: "Semi Bold" },
  { value: "700", label: "Bold" },
  { value: "800", label: "Extra Bold" },
  { value: "900", label: "Black" },
]

// Anchor point options
const anchorPoints = [
  { value: "left top", label: "Top Left", icon: "↖" },
  { value: "center top", label: "Top Center", icon: "↑" },
  { value: "right top", label: "Top Right", icon: "↗" },
  { value: "left center", label: "Center Left", icon: "←" },
  { value: "center center", label: "Center", icon: "·" },
  { value: "right center", label: "Center Right", icon: "→" },
  { value: "left bottom", label: "Bottom Left", icon: "↙" },
  { value: "center bottom", label: "Bottom Center", icon: "↓" },
  { value: "right bottom", label: "Bottom Right", icon: "↘" },
]

export function PropertiesPanel({
  activeObject,
  onUpdate,
  onDelete,
  onDuplicate,
  onReplaceImage,
  onBringToFront,
  onSendToBack,
  onBringForward,
  onSendBackward,
}: PropertiesPanelProps) {
  const [isCropping, setIsCropping] = useState(false)
  const [useGradient, setUseGradient] = useState(false)
  const [gradientType, setGradientType] = useState<"linear" | "radial">("linear")
  const [gradientAngle, setGradientAngle] = useState(0)
  const [gradientColors, setGradientColors] = useState(["#000000", "#FFFFFF"])
  const [showAdvancedColors, setShowAdvancedColors] = useState(false)

  // Local state for slider values (for immediate visual feedback)
  const [localOpacity, setLocalOpacity] = useState((activeObject?.opacity || 1) * 100)
  const [localFontSize, setLocalFontSize] = useState(activeObject?.fontSize || 48)
  const [localStrokeWidth, setLocalStrokeWidth] = useState(activeObject?.strokeWidth || 0)
  const [localAngle, setLocalAngle] = useState(activeObject?.angle || 0)
  const [localScale, setLocalScale] = useState((activeObject?.scaleX || 1) * 100)
  const [localShadowBlur, setLocalShadowBlur] = useState(activeObject?.shadow?.blur || 0)
  const [localLineHeight, setLocalLineHeight] = useState(activeObject?.lineHeight || 1.16)
  const [localCharSpacing, setLocalCharSpacing] = useState(activeObject?.charSpacing || 0)

  // Filter states
  const [brightness, setBrightness] = useState(0)
  const [contrast, setContrast] = useState(0)
  const [saturation, setSaturation] = useState(0)
  const [blur, setBlur] = useState(0)

  // Update local state when activeObject changes
  useEffect(() => {
    if (activeObject) {
      setLocalOpacity((activeObject.opacity || 1) * 100)
      setLocalFontSize(activeObject.fontSize || 48)
      setLocalStrokeWidth(activeObject.strokeWidth || 0)
      setLocalAngle(activeObject.angle || 0)
      setLocalScale((activeObject.scaleX || 1) * 100)
      setLocalShadowBlur(activeObject.shadow?.blur || 0)
      setLocalLineHeight(activeObject.lineHeight || 1.16)
      setLocalCharSpacing(activeObject.charSpacing || 0)
    }
  }, [activeObject])

  // Debounced update functions
  const debouncedUpdate = useDebounce(onUpdate, 50)

  // Memoize object type checks
  const objectTypes = useMemo(() => {
    if (!activeObject) return { isText: false, isImage: false, isShape: false }
    return {
      isText: activeObject.type === "textbox" || activeObject.type === "text",
      isImage: activeObject.type === "image",
      isShape: activeObject.type === "rect" || activeObject.type === "circle" || activeObject.type === "triangle",
    }
  }, [activeObject])

  const { isText, isImage, isShape } = objectTypes

  const currentAnchor = useMemo(() => {
    if (!activeObject) return "left top"
    return `${activeObject.originX || "left"} ${activeObject.originY || "top"}`
  }, [activeObject])

  const handleCropComplete = (croppedImageUrl: string) => {
    if (onReplaceImage) {
      onReplaceImage(croppedImageUrl)
    }
    setIsCropping(false)
  }

  const setAnchorPoint = useCallback(
    (value: string) => {
      const [originX, originY] = value.split(" ")
      onUpdate("originX", originX)
      onUpdate("originY", originY)
    },
    [onUpdate],
  )

  const applyGradient = useCallback(() => {
    if (gradientType === "linear") {
      const gradient = {
        type: "linear",
        coords: {
          x1: 0,
          y1: 0,
          x2: Math.cos((gradientAngle * Math.PI) / 180) * 100,
          y2: Math.sin((gradientAngle * Math.PI) / 180) * 100,
        },
        colorStops: gradientColors.map((color, index) => ({
          offset: index / (gradientColors.length - 1),
          color,
        })),
      }
      onUpdate("fill", gradient)
    } else {
      const gradient = {
        type: "radial",
        coords: { r1: 0, r2: 100 },
        colorStops: gradientColors.map((color, index) => ({
          offset: index / (gradientColors.length - 1),
          color,
        })),
      }
      onUpdate("fill", gradient)
    }
  }, [gradientType, gradientAngle, gradientColors, onUpdate])

  if (!activeObject) {
    return (
      <Card className="p-6 text-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
            <Layers className="w-8 h-8 text-muted-foreground" />
          </div>
          <div>
            <h3 className="font-semibold mb-1">No Selection</h3>
            <p className="text-sm text-muted-foreground">Select an element to edit its properties</p>
          </div>
        </div>
      </Card>
    )
  }

  const ColorPicker = ({
    value,
    onChange,
    label,
    allowGradient = false,
  }: {
    value: string
    onChange: (color: string) => void
    label: string
    allowGradient?: boolean
  }) => (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
        {allowGradient && (
          <Button
            variant={useGradient ? "default" : "outline"}
            size="sm"
            onClick={() => setUseGradient(!useGradient)}
            className="h-7 text-xs px-2 gap-1"
          >
            <Sparkles className="w-3 h-3" />
            {useGradient ? "Solid" : "Gradient"}
          </Button>
        )}
      </div>

      {!useGradient ? (
        <>
          <div className="flex gap-2">
            <div className="relative">
              <Input
                type="color"
                value={value || "#000000"}
                onChange={(e) => onChange(e.target.value)}
                className="h-10 w-10 p-1 cursor-pointer rounded-lg border-2"
              />
            </div>
            <Input
              type="text"
              value={value || "#000000"}
              onChange={(e) => onChange(e.target.value)}
              className="h-10 flex-1 text-xs font-mono"
              placeholder="#000000"
            />
          </div>

          <Tabs defaultValue={Object.keys(colorCategories)[0]} className="w-full">
            <TabsList className="w-full h-8 grid grid-cols-4 gap-1 bg-muted/50 p-0.5">
              {Object.keys(colorCategories).map((category) => (
                <TabsTrigger key={category} value={category} className="text-xs px-1 h-7">
                  {category.split(" ")[0]}
                </TabsTrigger>
              ))}
            </TabsList>
            {Object.entries(colorCategories).map(([category, colors]) => (
              <TabsContent key={category} value={category} className="mt-2">
                <div className="grid grid-cols-4 gap-1.5">
                  {colors.map(({ color, name }) => (
                    <button
                      key={color}
                      onClick={() => onChange(color)}
                      className="group relative w-full aspect-square rounded-md border-2 border-border hover:border-primary transition-all hover:scale-105"
                      style={{ backgroundColor: color }}
                      title={name}
                    >
                      {value === color && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-3 h-3 rounded-full bg-white border-2 border-gray-900" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </>
      ) : (
        <div className="space-y-3">
          <div className="flex gap-2">
            <Select value={gradientType} onValueChange={(v: "linear" | "radial") => setGradientType(v)}>
              <SelectTrigger className="h-9 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="linear">Linear</SelectItem>
                <SelectItem value="radial">Radial</SelectItem>
              </SelectContent>
            </Select>
            {gradientType === "linear" && (
              <div className="flex items-center gap-2 flex-1">
                <Input
                  type="number"
                  value={gradientAngle}
                  onChange={(e) => setGradientAngle(Number(e.target.value))}
                  className="h-9 text-xs"
                  min={0}
                  max={360}
                />
                <span className="text-xs text-muted-foreground">°</span>
              </div>
            )}
          </div>

          <div className="space-y-2">
            {gradientColors.map((color, index) => (
              <div key={index} className="flex gap-2">
                <Input
                  type="color"
                  value={color}
                  onChange={(e) => {
                    const newColors = [...gradientColors]
                    newColors[index] = e.target.value
                    setGradientColors(newColors)
                  }}
                  className="h-8 w-8 p-1 cursor-pointer"
                />
                <Input
                  type="text"
                  value={color}
                  onChange={(e) => {
                    const newColors = [...gradientColors]
                    newColors[index] = e.target.value
                    setGradientColors(newColors)
                  }}
                  className="h-8 flex-1 text-xs font-mono"
                />
                {gradientColors.length > 2 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setGradientColors(gradientColors.filter((_, i) => i !== index))}
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                )}
              </div>
            ))}
            {gradientColors.length < 5 && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setGradientColors([...gradientColors, "#000000"])}
                className="w-full h-8 text-xs"
              >
                Add Color Stop
              </Button>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            {gradientPresets.map((preset) => (
              <button
                key={preset.name}
                onClick={() => {
                  setGradientColors(preset.colors)
                  setGradientAngle(preset.angle)
                }}
                className="h-10 rounded-md border-2 border-border hover:border-primary transition-all relative overflow-hidden group"
                style={{
                  background: `linear-gradient(${preset.angle}deg, ${preset.colors.join(", ")})`,
                }}
                title={preset.name}
              >
                <span className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs font-medium">
                  {preset.name}
                </span>
              </button>
            ))}
          </div>

          <Button onClick={applyGradient} className="w-full" size="sm">
            Apply Gradient
          </Button>
        </div>
      )}
    </div>
  )

  return (
    <>
      <ScrollArea className="h-[calc(100vh-2rem)]">
        <Card className="p-4 space-y-3">
          {/* Header */}
          <div className="space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-base">Properties</h3>
                  <Badge variant="secondary" className="text-xs">
                    {isText ? (
                      <Type className="w-3 h-3 mr-1" />
                    ) : isImage ? (
                      <ImageIcon className="w-3 h-3 mr-1" />
                    ) : (
                      <Square className="w-3 h-3 mr-1" />
                    )}
                    {isText ? "Text" : isImage ? "Image" : activeObject.type}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {activeObject.id || "Unnamed Layer"}
                </p>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-4 gap-1.5">
              {onDuplicate && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onDuplicate}
                  className="gap-1.5 h-8 text-xs"
                  title="Duplicate"
                >
                  <Copy className="w-3.5 h-3.5" />
                </Button>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() => onUpdate("locked", !activeObject.lockMovementX)}
                className="gap-1.5 h-8 text-xs"
                title={activeObject.lockMovementX ? "Unlock" : "Lock"}
              >
                {activeObject.lockMovementX ? (
                  <Lock className="w-3.5 h-3.5" />
                ) : (
                  <Unlock className="w-3.5 h-3.5" />
                )}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onUpdate("visible", !activeObject.visible)}
                className="gap-1.5 h-8 text-xs"
                title={activeObject.visible === false ? "Show" : "Hide"}
              >
                {activeObject.visible === false ? (
                  <EyeOff className="w-3.5 h-3.5" />
                ) : (
                  <Eye className="w-3.5 h-3.5" />
                )}
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={onDelete}
                className="gap-1.5 h-8 text-xs"
                title="Delete"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>

            {/* Layer Order */}
            <div className="grid grid-cols-4 gap-1.5">
              <Button
                variant="outline"
                size="sm"
                onClick={onBringToFront}
                className="gap-1 h-8 text-xs"
                disabled={!onBringToFront}
                title="Bring to Front"
              >
                <ArrowUp className="w-3 h-3" />
                <ArrowUp className="w-3 h-3 -ml-2" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onBringForward}
                className="gap-1 h-8 text-xs"
                disabled={!onBringForward}
                title="Bring Forward"
              >
                <ArrowUp className="w-3 h-3" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onSendBackward}
                className="gap-1 h-8 text-xs"
                disabled={!onSendBackward}
                title="Send Backward"
              >
                <ArrowDown className="w-3 h-3" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onSendToBack}
                className="gap-1 h-8 text-xs"
                disabled={!onSendToBack}
                title="Send to Back"
              >
                <ArrowDown className="w-3 h-3" />
                <ArrowDown className="w-3 h-3 -ml-2" />
              </Button>
            </div>
          </div>

          <Separator />

          <Accordion type="multiple" defaultValue={["position", "appearance"]} className="w-full">
            {/* Position & Size */}
            <AccordionItem value="position" className="border-none">
              <AccordionTrigger className="py-2.5 hover:no-underline">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Move className="w-4 h-4 text-primary" />
                  </div>
                  <span className="text-sm font-medium">Position & Size</span>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs text-muted-foreground mb-1.5 block">X Position</Label>
                      <NumericInput
                        value={Math.round(activeObject.left || 0)}
                        onChange={(value) => onUpdate("left", value)}
                        className="h-9 text-xs"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground mb-1.5 block">Y Position</Label>
                      <NumericInput
                        value={Math.round(activeObject.top || 0)}
                        onChange={(value) => onUpdate("top", value)}
                        className="h-9 text-xs"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs text-muted-foreground mb-1.5 block">Width</Label>
                      <NumericInput
                        value={Math.round((activeObject.width || 0) * (activeObject.scaleX || 1))}
                        onChange={(value) => {
                          const newScaleX = value / (activeObject.width || 1)
                          onUpdate("scaleX", newScaleX)
                        }}
                        className="h-9 text-xs"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground mb-1.5 block">Height</Label>
                      <NumericInput
                        value={Math.round((activeObject.height || 0) * (activeObject.scaleY || 1))}
                        onChange={(value) => {
                          const newScaleY = value / (activeObject.height || 1)
                          onUpdate("scaleY", newScaleY)
                        }}
                        className="h-9 text-xs"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-xs text-muted-foreground">Lock Aspect Ratio</Label>
                    <Switch
                      checked={activeObject.lockScalingFlip || false}
                      onCheckedChange={(checked) => onUpdate("lockScalingFlip", checked)}
                    />
                  </div>

                  <Separator />

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <Label className="text-xs font-medium text-muted-foreground">Opacity</Label>
                      <div className="flex items-center gap-1.5">
                        <NumericInput
                          value={Math.round(localOpacity)}
                          onChange={(value) => {
                            setLocalOpacity(value)
                            onUpdate("opacity", value / 100)
                          }}
                          min={0}
                          max={100}
                          className="h-7 w-16 text-xs"
                        />
                        <span className="text-xs text-muted-foreground">%</span>
                      </div>
                    </div>
                    <Slider
                      value={[localOpacity]}
                      onValueChange={([v]) => {
                        setLocalOpacity(v)
                        debouncedUpdate("opacity", v / 100)
                      }}
                      min={0}
                      max={100}
                      step={1}
                      className="cursor-pointer"
                    />
                  </div>

                  {/* Alignment Helpers */}
                  <div>
                    <Label className="text-xs text-muted-foreground mb-2 block">Quick Align</Label>
                    <div className="grid grid-cols-3 gap-1.5">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 text-xs gap-1"
                        onClick={() => onUpdate("left", 0)}
                        title="Align Left"
                      >
                        <AlignLeft className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 text-xs gap-1"
                        onClick={() => onUpdate("left", 400)}
                        title="Center Horizontally"
                      >
                        <AlignHorizontalJustifyCenter className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 text-xs gap-1"
                        onClick={() => onUpdate("left", 800)}
                        title="Align Right"
                      >
                        <AlignRight className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* Text Properties */}
            {isText && (
              <AccordionItem value="text" className="border-none">
                <AccordionTrigger className="py-2.5 hover:no-underline">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                      <Type className="w-4 h-4 text-blue-500" />
                    </div>
                    <span className="text-sm font-medium">Text Style</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4 pt-2">
                    <div>
                      <Label className="text-xs text-muted-foreground mb-1.5 block">Text Content</Label>
                      <Input
                        value={activeObject.text || ""}
                        onChange={(e) => onUpdate("text", e.target.value)}
                        placeholder="Enter text..."
                        className="text-sm"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label className="text-xs text-muted-foreground mb-1.5 block">Font Family</Label>
                        <Select
                          value={activeObject.fontFamily || "Arial"}
                          onValueChange={(v) => onUpdate("fontFamily", v)}
                        >
                          <SelectTrigger className="h-9 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {fontFamilies.map((font) => (
                              <SelectItem key={font} value={font}>
                                {font}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-xs text-muted-foreground mb-1.5 block">Font Weight</Label>
                        <Select
                          value={String(activeObject.fontWeight || "400")}
                          onValueChange={(v) => onUpdate("fontWeight", v)}
                        >
                          <SelectTrigger className="h-9 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {fontWeights.map((weight) => (
                              <SelectItem key={weight.value} value={weight.value}>
                                {weight.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-xs font-medium text-muted-foreground">Font Size</Label>
                        <div className="flex items-center gap-1.5">
                          <NumericInput
                            value={localFontSize}
                            onChange={(value) => {
                              setLocalFontSize(value)
                              onUpdate("fontSize", value)
                            }}
                            min={8}
                            max={200}
                            className="h-7 w-16 text-xs"
                          />
                          <span className="text-xs text-muted-foreground">px</span>
                        </div>
                      </div>
                      <Slider
                        value={[localFontSize]}
                        onValueChange={([v]) => {
                          setLocalFontSize(v)
                          debouncedUpdate("fontSize", v)
                        }}
                        min={8}
                        max={200}
                        step={1}
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-xs font-medium text-muted-foreground">Line Height</Label>
                        <NumericInput
                          value={Number(localLineHeight.toFixed(2))}
                          onChange={(value) => {
                            setLocalLineHeight(value)
                            onUpdate("lineHeight", value)
                          }}
                          min={0.5}
                          max={3}
                          step={0.1}
                          className="h-7 w-16 text-xs"
                        />
                      </div>
                      <Slider
                        value={[localLineHeight]}
                        onValueChange={([v]) => {
                          setLocalLineHeight(v)
                          debouncedUpdate("lineHeight", v)
                        }}
                        min={0.5}
                        max={3}
                        step={0.1}
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-xs font-medium text-muted-foreground">Letter Spacing</Label>
                        <div className="flex items-center gap-1.5">
                          <NumericInput
                            value={localCharSpacing}
                            onChange={(value) => {
                              setLocalCharSpacing(value)
                              onUpdate("charSpacing", value)
                            }}
                            min={-200}
                            max={800}
                            className="h-7 w-16 text-xs"
                          />
                          <span className="text-xs text-muted-foreground">px</span>
                        </div>
                      </div>
                      <Slider
                        value={[localCharSpacing]}
                        onValueChange={([v]) => {
                          setLocalCharSpacing(v)
                          debouncedUpdate("charSpacing", v)
                        }}
                        min={-200}
                        max={800}
                        step={10}
                      />
                    </div>

                    <Separator />

                    <ColorPicker
                      value={activeObject.fill || "#000000"}
                      onChange={(color) => onUpdate("fill", color)}
                      label="Text Color"
                      allowGradient={true}
                    />

                    <Separator />

                    <div>
                      <Label className="text-xs text-muted-foreground mb-2 block">Text Style</Label>
                      <div className="flex gap-1.5">
                        <Button
                          variant={
                            activeObject.fontWeight === "bold" || activeObject.fontWeight === 700
                              ? "default"
                              : "outline"
                          }
                          size="icon"
                          className="h-9 w-9"
                          onClick={() =>
                            onUpdate(
                              "fontWeight",
                              activeObject.fontWeight === "bold" || activeObject.fontWeight === 700
                                ? "normal"
                                : "bold",
                            )
                          }
                        >
                          <Bold className="w-4 h-4" />
                        </Button>
                        <Button
                          variant={activeObject.fontStyle === "italic" ? "default" : "outline"}
                          size="icon"
                          className="h-9 w-9"
                          onClick={() =>
                            onUpdate("fontStyle", activeObject.fontStyle === "italic" ? "normal" : "italic")
                          }
                        >
                          <Italic className="w-4 h-4" />
                        </Button>
                        <Button
                          variant={activeObject.underline ? "default" : "outline"}
                          size="icon"
                          className="h-9 w-9"
                          onClick={() => onUpdate("underline", !activeObject.underline)}
                        >
                          <Underline className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div>
                      <Label className="text-xs text-muted-foreground mb-2 block">Text Alignment</Label>
                      <div className="flex gap-1.5">
                        <Button
                          variant={activeObject.textAlign === "left" ? "default" : "outline"}
                          size="icon"
                          className="h-9 w-9"
                          onClick={() => onUpdate("textAlign", "left")}
                        >
                          <AlignLeft className="w-4 h-4" />
                        </Button>
                        <Button
                          variant={activeObject.textAlign === "center" ? "default" : "outline"}
                          size="icon"
                          className="h-9 w-9"
                          onClick={() => onUpdate("textAlign", "center")}
                        >
                          <AlignCenter className="w-4 h-4" />
                        </Button>
                        <Button
                          variant={activeObject.textAlign === "right" ? "default" : "outline"}
                          size="icon"
                          className="h-9 w-9"
                          onClick={() => onUpdate("textAlign", "right")}
                        >
                          <AlignRight className="w-4 h-4" />
                        </Button>
                        <Button
                          variant={activeObject.textAlign === "justify" ? "default" : "outline"}
                          size="icon"
                          className="h-9 w-9"
                          onClick={() => onUpdate("textAlign", "justify")}
                        >
                          <AlignJustify className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}

            {/* Shape/Image Appearance */}
            {(isShape || isImage) && (
              <AccordionItem value="appearance" className="border-none">
                <AccordionTrigger className="py-2.5 hover:no-underline">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center">
                      <Palette className="w-4 h-4 text-purple-500" />
                    </div>
                    <span className="text-sm font-medium">Appearance</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4 pt-2">
                    {isShape && (
                      <ColorPicker
                        value={typeof activeObject.fill === "string" ? activeObject.fill : "#000000"}
                        onChange={(color) => onUpdate("fill", color)}
                        label="Fill Color"
                        allowGradient={true}
                      />
                    )}

                    {isImage && (
                      <div>
                        <Label className="text-xs text-muted-foreground mb-2 block">Blend Mode</Label>
                        <Select
                          value={activeObject.globalCompositeOperation || "normal"}
                          onValueChange={(v) => onUpdate("globalCompositeOperation", v)}
                        >
                          <SelectTrigger className="h-9 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {blendModes.map((mode) => (
                              <SelectItem key={mode} value={mode} className="capitalize">
                                {mode.replace("-", " ")}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}

            {/* Stroke */}
            <AccordionItem value="stroke" className="border-none">
              <AccordionTrigger className="py-2.5 hover:no-underline">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-orange-500/10 flex items-center justify-center">
                    <Minus className="w-4 h-4 text-orange-500" />
                  </div>
                  <span className="text-sm font-medium">Stroke</span>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs text-muted-foreground">Enable Stroke</Label>
                    <Switch
                      checked={(activeObject.strokeWidth || 0) > 0}
                      onCheckedChange={(checked) => onUpdate("strokeWidth", checked ? 2 : 0)}
                    />
                  </div>

                  {(activeObject.strokeWidth || 0) > 0 && (
                    <>
                      <ColorPicker
                        value={activeObject.stroke || "#000000"}
                        onChange={(color) => onUpdate("stroke", color)}
                        label="Stroke Color"
                      />

                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <Label className="text-xs font-medium text-muted-foreground">Stroke Width</Label>
                          <div className="flex items-center gap-1.5">
                            <NumericInput
                              value={localStrokeWidth}
                              onChange={(value) => {
                                setLocalStrokeWidth(value)
                                onUpdate("strokeWidth", value)
                              }}
                              min={0}
                              max={50}
                              className="h-7 w-16 text-xs"
                            />
                            <span className="text-xs text-muted-foreground">px</span>
                          </div>
                        </div>
                        <Slider
                          value={[localStrokeWidth]}
                          onValueChange={([v]) => {
                            setLocalStrokeWidth(v)
                            debouncedUpdate("strokeWidth", v)
                          }}
                          min={0}
                          max={50}
                          step={1}
                        />
                      </div>

                      <div>
                        <Label className="text-xs text-muted-foreground mb-2 block">Stroke Style</Label>
                        <Select
                          value={activeObject.strokeDashArray ? "dashed" : "solid"}
                          onValueChange={(v) => onUpdate("strokeDashArray", v === "dashed" ? [5, 5] : null)}
                        >
                          <SelectTrigger className="h-9 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="solid">Solid</SelectItem>
                            <SelectItem value="dashed">Dashed</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </>
                  )}
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* Transform */}
            <AccordionItem value="transform" className="border-none">
              <AccordionTrigger className="py-2.5 hover:no-underline">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-green-500/10 flex items-center justify-center">
                    <RotateCw className="w-4 h-4 text-green-500" />
                  </div>
                  <span className="text-sm font-medium">Transform</span>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <Label className="text-xs font-medium text-muted-foreground">Rotation</Label>
                      <div className="flex items-center gap-1.5">
                        <NumericInput
                          value={Math.round(localAngle)}
                          onChange={(value) => {
                            setLocalAngle(value)
                            onUpdate("angle", value)
                          }}
                          min={-180}
                          max={180}
                          className="h-7 w-16 text-xs"
                        />
                        <span className="text-xs text-muted-foreground">°</span>
                      </div>
                    </div>
                    <Slider
                      value={[localAngle]}
                      onValueChange={([v]) => {
                        setLocalAngle(v)
                        debouncedUpdate("angle", v)
                      }}
                      min={-180}
                      max={180}
                      step={1}
                    />
                    <div className="flex gap-1.5 mt-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 h-8 text-xs"
                        onClick={() => {
                          const newAngle = Math.round((localAngle - 90) % 360)
                          setLocalAngle(newAngle)
                          onUpdate("angle", newAngle)
                        }}
                      >
                        -90°
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 h-8 text-xs"
                        onClick={() => {
                          setLocalAngle(0)
                          onUpdate("angle", 0)
                        }}
                      >
                        Reset
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 h-8 text-xs"
                        onClick={() => {
                          const newAngle = Math.round((localAngle + 90) % 360)
                          setLocalAngle(newAngle)
                          onUpdate("angle", newAngle)
                        }}
                      >
                        +90°
                      </Button>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <Label className="text-xs text-muted-foreground mb-2 block">Transform Origin</Label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {anchorPoints.map((point) => (
                        <Button
                          key={point.value}
                          variant={currentAnchor === point.value ? "default" : "outline"}
                          size="sm"
                          className="h-10 text-lg font-mono"
                          onClick={() => setAnchorPoint(point.value)}
                          title={point.label}
                        >
                          {point.icon}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <Label className="text-xs font-medium text-muted-foreground">Scale</Label>
                      <div className="flex items-center gap-1.5">
                        <NumericInput
                          value={Math.round(localScale)}
                          onChange={(value) => {
                            setLocalScale(value)
                            const scale = value / 100
                            onUpdate("scaleX", scale)
                            onUpdate("scaleY", scale)
                          }}
                          min={10}
                          max={500}
                          className="h-7 w-16 text-xs"
                        />
                        <span className="text-xs text-muted-foreground">%</span>
                      </div>
                    </div>
                    <Slider
                      value={[localScale]}
                      onValueChange={([v]) => {
                        setLocalScale(v)
                        const scale = v / 100
                        debouncedUpdate("scaleX", scale)
                        debouncedUpdate("scaleY", scale)
                      }}
                      min={10}
                      max={500}
                      step={1}
                    />
                  </div>

                  <Separator />

                  <div>
                    <Label className="text-xs text-muted-foreground mb-2 block">Flip</Label>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        className="flex-1 gap-2"
                        size="sm"
                        onClick={() => onUpdate("flipX", !activeObject.flipX)}
                      >
                        <FlipHorizontal className="w-4 h-4" />
                        Horizontal
                      </Button>
                      <Button
                        variant="outline"
                        className="flex-1 gap-2"
                        size="sm"
                        onClick={() => onUpdate("flipY", !activeObject.flipY)}
                      >
                        <FlipVertical className="w-4 h-4" />
                        Vertical
                      </Button>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* Image Filters */}
            {isImage && (
              <AccordionItem value="filters" className="border-none">
                <AccordionTrigger className="py-2.5 hover:no-underline">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-pink-500/10 flex items-center justify-center">
                      <Filter className="w-4 h-4 text-pink-500" />
                    </div>
                    <span className="text-sm font-medium">Filters</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4 pt-2">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                          <Sun className="w-3 h-3" />
                          Brightness
                        </Label>
                        <div className="flex items-center gap-1.5">
                          <NumericInput
                            value={brightness}
                            onChange={setBrightness}
                            min={-100}
                            max={100}
                            className="h-7 w-16 text-xs"
                          />
                        </div>
                      </div>
                      <Slider value={[brightness]} onValueChange={([v]) => setBrightness(v)} min={-100} max={100} />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                          <Contrast className="w-3 h-3" />
                          Contrast
                        </Label>
                        <NumericInput
                          value={contrast}
                          onChange={setContrast}
                          min={-100}
                          max={100}
                          className="h-7 w-16 text-xs"
                        />
                      </div>
                      <Slider value={[contrast]} onValueChange={([v]) => setContrast(v)} min={-100} max={100} />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                          <Droplet className="w-3 h-3" />
                          Saturation
                        </Label>
                        <NumericInput
                          value={saturation}
                          onChange={setSaturation}
                          min={-100}
                          max={100}
                          className="h-7 w-16 text-xs"
                        />
                      </div>
                      <Slider value={[saturation]} onValueChange={([v]) => setSaturation(v)} min={-100} max={100} />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                          <Zap className="w-3 h-3" />
                          Blur
                        </Label>
                        <NumericInput value={blur} onChange={setBlur} min={0} max={20} className="h-7 w-16 text-xs" />
                      </div>
                      <Slider value={[blur]} onValueChange={([v]) => setBlur(v)} min={0} max={20} />
                    </div>

                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="flex-1" onClick={() => {}}>
                        <RefreshCw className="w-3 h-3 mr-1.5" />
                        Apply Filters
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => {
                          setBrightness(0)
                          setContrast(0)
                          setSaturation(0)
                          setBlur(0)
                        }}
                      >
                        Reset
                      </Button>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}

            {/* Image Crop */}
            {isImage && (
              <AccordionItem value="crop" className="border-none">
                <AccordionTrigger className="py-2.5 hover:no-underline">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                      <Crop className="w-4 h-4 text-cyan-500" />
                    </div>
                    <span className="text-sm font-medium">Crop & Resize</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3 pt-2">
                    <Button variant="default" size="sm" onClick={() => setIsCropping(true)} className="w-full gap-2">
                      <Crop className="w-4 h-4" />
                      Crop Image
                    </Button>
                    <div className="grid grid-cols-2 gap-2">
                      <Button variant="outline" size="sm" className="gap-1.5">
                        <Grid3x3 className="w-3 h-3" />
                        1:1
                      </Button>
                      <Button variant="outline" size="sm" className="gap-1.5">
                        <Grid3x3 className="w-3 h-3" />
                        16:9
                      </Button>
                      <Button variant="outline" size="sm" className="gap-1.5">
                        <Grid3x3 className="w-3 h-3" />
                        4:3
                      </Button>
                      <Button variant="outline" size="sm" className="gap-1.5">
                        <Grid3x3 className="w-3 h-3" />
                        Free
                      </Button>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}

            {/* Shadow */}
            <AccordionItem value="shadow" className="border-none">
              <AccordionTrigger className="py-2.5 hover:no-underline">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gray-500/10 flex items-center justify-center">
                    <Layers className="w-4 h-4 text-gray-500" />
                  </div>
                  <span className="text-sm font-medium">Shadow & Effects</span>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs text-muted-foreground">Enable Shadow</Label>
                    <Switch
                      checked={!!activeObject.shadow}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          onUpdate("shadow", {
                            color: "#000000",
                            blur: 10,
                            offsetX: 5,
                            offsetY: 5,
                          })
                        } else {
                          onUpdate("shadow", null)
                        }
                      }}
                    />
                  </div>

                  {activeObject.shadow && (
                    <>
                      <ColorPicker
                        value={activeObject.shadow?.color || "#000000"}
                        onChange={(color) => {
                          const shadow = activeObject.shadow || {}
                          onUpdate("shadow", {
                            ...shadow,
                            color,
                            blur: shadow.blur || 10,
                            offsetX: shadow.offsetX || 5,
                            offsetY: shadow.offsetY || 5,
                          })
                        }}
                        label="Shadow Color"
                      />

                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <Label className="text-xs font-medium text-muted-foreground">Blur</Label>
                          <div className="flex items-center gap-1.5">
                            <NumericInput
                              value={activeObject.shadow?.blur || 0}
                              onChange={(v) => {
                                const shadow = activeObject.shadow || {}
                                onUpdate("shadow", {
                                  ...shadow,
                                  blur: v,
                                  color: shadow.color || "#000000",
                                  offsetX: shadow.offsetX || 5,
                                  offsetY: shadow.offsetY || 5,
                                })
                              }}
                              min={0}
                              max={50}
                              className="h-7 w-16 text-xs"
                            />
                            <span className="text-xs text-muted-foreground">px</span>
                          </div>
                        </div>
                        <Slider
                          value={[activeObject.shadow?.blur || 0]}
                          onValueCommit={([v]) => {
                            const shadow = activeObject.shadow || {}
                            onUpdate("shadow", {
                              ...shadow,
                              blur: v,
                              color: shadow.color || "#000000",
                              offsetX: shadow.offsetX || 5,
                              offsetY: shadow.offsetY || 5,
                            })
                          }}
                          min={0}
                          max={50}
                          step={1}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs text-muted-foreground mb-1.5 block">Offset X</Label>
                          <NumericInput
                            value={activeObject.shadow?.offsetX || 0}
                            onChange={(v) => {
                              const shadow = activeObject.shadow || {}
                              onUpdate("shadow", {
                                ...shadow,
                                offsetX: v,
                                color: shadow.color || "#000000",
                                blur: shadow.blur || 10,
                                offsetY: shadow.offsetY || 5,
                              })
                            }}
                            min={-50}
                            max={50}
                            className="h-9 text-xs"
                          />
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground mb-1.5 block">Offset Y</Label>
                          <NumericInput
                            value={activeObject.shadow?.offsetY || 0}
                            onChange={(v) => {
                              const shadow = activeObject.shadow || {}
                              onUpdate("shadow", {
                                ...shadow,
                                offsetY: v,
                                color: shadow.color || "#000000",
                                blur: shadow.blur || 10,
                                offsetX: shadow.offsetX || 5,
                              })
                            }}
                            min={-50}
                            max={50}
                            className="h-9 text-xs"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-1.5">
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => {
                            const shadow = activeObject.shadow || {}
                            onUpdate("shadow", { ...shadow, offsetX: 0, offsetY: -10 })
                          }}
                        >
                          Top
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => {
                            const shadow = activeObject.shadow || {}
                            onUpdate("shadow", { ...shadow, offsetX: 10, offsetY: 10 })
                          }}
                        >
                          Right
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => {
                            const shadow = activeObject.shadow || {}
                            onUpdate("shadow", { ...shadow, offsetX: 0, offsetY: 10 })
                          }}
                        >
                          Bottom
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </Card>
      </ScrollArea>

      {isCropping && activeObject?._element?.src && (
        <ImageCropper
          imageUrl={activeObject._element.src}
          onCropComplete={handleCropComplete}
          onCancel={() => setIsCropping(false)}
          aspectRatio={activeObject.width / activeObject.height}
        />
      )}
    </>
  )
}