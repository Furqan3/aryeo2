/**
 * @deprecated Use PosterEditor from @/components/editor/poster-editor instead
 * This file is kept for backward compatibility only
 */
export { PosterEditor as SimplePosterEditor } from "@/components/editor/poster-editor"
